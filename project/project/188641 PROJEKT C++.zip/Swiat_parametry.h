#pragma once

class Swiat_parametry
{
private:
	int width;
	int height;
public:
	Swiat_parametry();
	int getWidth();
	int getHeight();
};
